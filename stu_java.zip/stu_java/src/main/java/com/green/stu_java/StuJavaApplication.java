package com.green.stu_java;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StuJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(StuJavaApplication.class, args);
	}

}
