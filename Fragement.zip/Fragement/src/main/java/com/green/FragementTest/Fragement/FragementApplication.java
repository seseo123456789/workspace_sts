package com.green.FragementTest.Fragement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FragementApplication {

	public static void main(String[] args) {
		SpringApplication.run(FragementApplication.class, args);
	}

}
